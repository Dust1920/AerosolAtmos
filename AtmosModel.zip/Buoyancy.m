%Gerardo Hernandez Duenas
%Evolution using one step of Runge-Kutta
%LcpTheta0 = L/(cp*thetao)
function b = Buoyancy(z,qv0,theta0,g,epsbar,qv,qr,theta) 

%LcpTheta0,B

%qt = Qt_parcel0;
%thetae = Thetae_parcel0;

%Environment
Theta_env = 0; %theta0+B*z;
Qv_env = FQv(z,qv0);
%Thetae_env = Theta_env+LcpTheta0*theta0*Qv_env;
Thetav_env = Theta_env + epsbar*theta0*Qv_env;

%Parcel:
%qt = qv+qr;
%Qvs = FQv(z,qvs0);
%Qv_parcel = min(qt,Qvs);
%ThetaE_parcel = theta+LcpTheta0*theta0*qv;
%Qr_parcel = max(qt-Qv_parcel,0);
Thetav_parcel = theta + epsbar*theta0*qv-theta0*qr;

b = (g/theta0)*(Thetav_parcel-Thetav_env);

%b = (g/theta0)*(theta-Theta_env);