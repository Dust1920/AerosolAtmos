function AerosolsStoch


rng(200)
u = 1;
%% Scales:
Ths = 3; %In kelvin
qs = 1000; % This is because 1000 g/kg = 1
Us = 11.11; %in m/s
Ls = 10; %In km
Ts = 15; %In minutes

NoFrames = 100;

gamma = 0.3/3; 
tau_c_ref = 0.15/1;
tau_r = 0.015*1;

CCN_factor = .5;
CCNs = 1000; 
CCNzo = 1200*CCN_factor; 
CCNzo = CCNzo/CCNs;
CCNpick = 500*CCN_factor; 
CCNpick = CCNpick/CCNs;
CCNint = 300*CCN_factor; 
CCNint = CCNint/CCNs;
CCNhigh = 350*CCN_factor; 
CCNhigh = CCNhigh/CCNs;

%% Parameters:
%Dimensions and time
Nz = 100;
Lz = 15; %In km
Lz = Lz/Ls; dz = Lz/Nz;
T = 60; %In minutes
T = T/Ts;
% Thermodinamic parameters
epsbar = 0.6; %LH = 25/3; 
theta0 = 300; % In kelvin
theta0 = theta0/Ths;
g = 9.81; %in m/s^2
g = g/(9.81)*794.61; %Non-dimensional
B = 3; %In K/km
B = B*Ls/Ths; %For envoronment potential temperature
% Moisture
qv0 = 15; %In g/kg;
qv0 = qv0/qs;
qvs0 = 20; %In g/kg;
qvs0 = qvs0/qs;

%b_w_exact = .05;

tau_w = 0.05;

ampl_bubble = 3.5; %In g/kg
ampl_bubble = ampl_bubble/qs;
% ampl_q = 1; %In g/kg
% ampl_q = ampl_q/qs;
q_star = 10; %In g/kg
q_star = q_star/qs;

VT0 = 10; %In m/s
VT0 = VT0/Us;
VTNd = .01; % in m/s
VTNd = VTNd/Us;

CFL = 0.9/2;

% tau_c = 0.15*1; %In minutes
% tau_c = tau_c/Ts;
% 
% tau_e = 0.1*tau_c;

LcpTheta0 = 25/3; %L/(c_p*theta0)

%% Initial profiles

z_axis = zeros(Nz+1,1);
qvs = zeros(Nz+1,1);
for iz = 1:Nz+1
    zi = (iz-1)*dz;
    z_axis(iz,1) = zi;
    
    qvs(iz,1) = FQv(zi,qvs0);
end

%% PDEs:

%Initial conditions:
w_n = zeros(Nz+1,1);
theta_prime_n = zeros(Nz+1,1); %Fluctuating potential temperature
qv_n = zeros(Nz+1,1);
qr_n = zeros(Nz+1,1);
qN_n = zeros(Nz+1,1);
theta_env = zeros(Nz+1,1);
BouyancyForce = zeros(Nz+1,1);

for iz = 1:Nz+1
    zi = z_axis(iz,1);
    
    qv_n(iz,1) = FQv(zi,qv0);

    %Introduce perturbation:
    if abs(zi-0.3) < 0.2
        qv_n(iz,1) = qv_n(iz,1) + ampl_bubble*(((zi-.3-.2)/.2)^2)*(((zi-.3+0.2)/.2)^2);
    end
%     if abs(zi-0.3) < 0.2
%         qN_n(iz,1) = ampl_q*(((zi-.3-.2)/.2)^2)*(((zi-.3+0.2)/.2)^2);
%     end
    
    theta_prime_n(iz,1) = 0;

    theta_env(iz,1) = theta0+B*zi;
end

for iz = 1:Nz+1
    zi = z_axis(iz,1);
    if 4/Ls <= zi && zi <= 5/Ls		
        qN_n(iz,1) =  CCNhigh*(0.5-zi)/(0.5-0.4);
    end
    if 2/Ls <= zi && zi <= 4/Ls	
        qN_n(iz,1) = CCNhigh+(CCNint-CCNhigh)*(zi-0.4)/(0.2-0.4);
    end				
    if 1.5/Ls <= zi && zi <= 2/Ls		
        qN_n(iz,1) = CCNint+(CCNpick-CCNint)*(zi-0.2)/(0.15-0.2);
    end
    if 1/Ls <= zi && zi <= 1.5/Ls	
        qN_n(iz,1) =  CCNpick + ( CCNint-CCNpick )*(zi-0.15)/(0.1-0.15);
    end
    if zi <= 1/Ls		
        qN_n(iz,1) = CCNint + ( CCNzo -CCNpick )*(zi-0.1)/(0.0-0.1);
    end
end

t = 0;

theta_prime_np1 = theta_prime_n;
qv_np1 = qv_n;
qr_np1 = qr_n;
w_np1 = w_n;
qN_np1 = qN_n;

dt0 = 10/60/Ts;

nu = 0.01*0 ;
b_w_exact = 0.05;
frame = 0;
step = 0;
while t < T
        
    %VT = VT0*qr_n/(q_star/10*2); %Revisar
    %VT_prime = VT0/(q_star/10*2); %Revisar
    
    VT = VT0*qr_n/(q_star); %Revisar
    VT_prime = VT0/(q_star); %Revisar
    
    VTN = VTNd + min(qr_n/q_star).*max(VT-VTNd,0);
    
    wr_n = w_n - VT - VT_prime*qr_n;
    wN_n = w_n - VTN;

    dt = CFL*dz/max(max(abs(w_n)),max(max(abs(wr_n)),max(abs(wN_n))));
    
    dt = min(dt,tau_w/10);
    dt = min(dt,dt0);

    if nu > 0 %Stability
        dt = min(dt,0.9*.5/nu*dz^2);
    end
    
    M = 20; %Number of wave modes
    dW = sqrt(dt)*randn(M,1);

    for iz = 2:Nz
        
        tau_c_inv = exp(-((qN_n(iz,1)-0.5)/gamma)^2)/tau_c_ref
        
        Cd = max(qv_n(iz,1)-qvs(iz,1),0)*tau_c_inv;
        Er = max(qvs(iz,1)-qv_n(iz,1),0)/tau_r*qr_n(iz,1)/q_star;
        
        zi = z_axis(iz,1);
        b = Buoyancy(zi,qv0,theta0,g,epsbar,qv_n(iz,1),qr_n(iz,1),theta_prime_n(iz,1));
        
        BouyancyForce(iz,1) = b;
        
        w_np1(iz,1) = w_np1(iz,1)+ b*dt; %Forward Euler dw/dt = b 
            
        %For w, we use Euler-Maruyama for an Ornstein-Uhlenbeck process
        if b_w_exact > 0
            w_np1(iz,1) = w_np1(iz,1) - w_n(iz,1)*dt/tau_w; %*exp((zi/Lz-1)); 
            %Forcing at different wavenumbers
            Hz = 12/Ls;
            if zi < Hz
                for m = 1:M
                    w_np1(iz,1) = w_np1(iz,1) + u * b_w_exact*dW(m,1)*sin(m*pi*zi/Hz);
                end
            end
        end
        
        w_imhalf = (w_n(iz-1,1)+w_n(iz,1))/2;
        w_iphalf = (w_n(iz,1)+w_n(iz+1,1))/2;
        
        wr_imhalf = (wr_n(iz-1,1)+wr_n(iz,1))/2;
        wr_iphalf = (wr_n(iz,1)+wr_n(iz+1,1))/2;

        wN_imhalf = (wN_n(iz-1,1)+wN_n(iz,1))/2;
        wN_iphalf = (wN_n(iz,1)+wN_n(iz+1,1))/2;
        
        if w_n(iz-1,1) < 0 && 0 <= w_n(iz,1) %Entropy fix
            w_imhalf_right = w_n(iz,1)*((w_imhalf-w_n(iz-1,1))/(w_n(iz,1)-w_n(iz-1,1)));
            
            theta_prime_imhalf = (theta_prime_n(iz,1)+theta_prime_n(iz-1,1))/2;
            theta_prime_np1(iz,1) = theta_prime_np1(iz,1) - dt/dz*w_imhalf_right*(theta_prime_n(iz,1)-theta_prime_n(iz-1,1))-dt/dz*theta_prime_imhalf*(w_n(iz,1)-w_n(iz-1,1));
            % % Substract background advection:
            % theta_env_imhalf = (theta_env(iz,1)+theta_env(iz-1,1))/2;
            % theta_prime_np1(iz,1) = theta_prime_np1(iz,1) - dt/dz*w_imhalf_right*(theta_env(iz,1)-theta_env(iz-1,1))-dt/dz*theta_env_imhalf*(w_n(iz,1)-w_n(iz-1,1));

            qv_imhalf = (qv_n(iz,1)+qv_n(iz-1,1))/2;
            qv_np1(iz,1) = qv_np1(iz,1) - dt/dz*w_imhalf_right*(qv_n(iz,1)-qv_n(iz-1,1))-dt/dz*qv_imhalf*(w_n(iz,1)-w_n(iz-1,1));
            
            w_imhalf = (w_n(iz,1)+w_n(iz-1,1))/2;
            w_np1(iz,1) = w_np1(iz,1) - dt/dz*w_imhalf_right*(w_n(iz,1)-w_n(iz-1,1))-dt/dz*w_imhalf*(w_n(iz,1)-w_n(iz-1,1));            
        else
            if w_imhalf > 0 % Upwind approach: d th/dt = - d(w*th)/dz
                theta_prime_np1(iz,1) = theta_prime_np1(iz,1) - dt/dz*(w_n(iz,1)*theta_prime_n(iz,1)-w_n(iz-1,1)*theta_prime_n(iz-1,1));
                % %Substract background advection
                % theta_prime_np1(iz,1) = theta_prime_np1(iz,1) - dt/dz*(w_n(iz,1)*theta_env(iz,1)-w_n(iz-1,1)*theta_env(iz-1,1));
                qv_np1(iz,1) = qv_np1(iz,1) - dt/dz*(w_n(iz,1)*qv_n(iz,1)-w_n(iz-1,1)*qv_n(iz-1,1)) ;
                w_np1(iz,1) = w_np1(iz,1) - dt/dz*(w_n(iz,1)*w_n(iz,1)-w_n(iz-1,1)*w_n(iz-1,1)) ;
            end
        end
        if w_n(iz,1) < 0 && 0 <= w_n(iz+1,1)
            w_iphalf_left = w_n(iz,1)*((w_n(iz+1,1)-w_iphalf)/(w_n(iz+1,1)-w_n(iz,1)));

            theta_prime_iphalf = (theta_prime_n(iz+1,1)+theta_prime_n(iz,1))/2;
            theta_prime_np1(iz,1) = theta_prime_np1(iz,1) - dt/dz*w_iphalf_left*(theta_prime_n(iz+1,1)-theta_prime_n(iz,1))-dt/dz*theta_prime_iphalf*(w_n(iz+1,1)-w_n(iz,1));
            % %Substract background:
            % theta_env_iphalf = (theta_env(iz+1,1)+theta_env(iz,1))/2;
            % theta_prime_np1(iz,1) = theta_prime_np1(iz,1) - dt/dz*w_iphalf_left*(theta_env(iz+1,1)-theta_env(iz,1))-dt/dz*theta_env_iphalf*(w_n(iz+1,1)-w_n(iz,1));

            qv_iphalf = (qv_n(iz+1,1)+qv_n(iz,1))/2;
            qv_np1(iz,1) = qv_np1(iz,1) - dt/dz*w_iphalf_left*(qv_n(iz+1,1)-qv_n(iz,1))-dt/dz*qv_iphalf*(w_n(iz+1,1)-w_n(iz,1));
        
            w_iphalf = (w_n(iz+1,1)+w_n(iz,1))/2;
            w_np1(iz,1) = w_np1(iz,1) - dt/dz*w_iphalf_left*(w_n(iz+1,1)-w_n(iz,1))-dt/dz*w_iphalf*(w_n(iz+1,1)-w_n(iz,1));
        else       
            if w_iphalf < 0 
                theta_prime_np1(iz,1) = theta_prime_np1(iz,1) - dt/dz*(w_n(iz+1,1)*theta_prime_n(iz+1,1)-w_n(iz,1)*theta_prime_n(iz,1));
                % %Substract background
                % theta_prime_np1(iz,1) = theta_prime_np1(iz,1) - dt/dz*(w_n(iz+1,1)*theta_env(iz+1,1)-w_n(iz,1)*theta_env(iz,1));
                qv_np1(iz,1) = qv_np1(iz,1) - dt/dz*(w_n(iz+1,1)*qv_n(iz+1,1)-w_n(iz,1)*qv_n(iz,1));
                w_np1(iz,1) = w_np1(iz,1) - dt/dz*(w_n(iz+1,1)*w_n(iz+1,1)-w_n(iz,1)*w_n(iz,1));
            end
        end
        %Latent hear release:
        theta_prime_np1(iz,1) = theta_prime_np1(iz,1) + LcpTheta0*theta0*(Cd-Er)*dt; % - dt/tau_th*theta_prime_n(iz,1); % + b_th*dW(it,ins,iz);   
        %Condensatio and evaporation parametrizations:
        qv_np1(iz,1) = qv_np1(iz,1) + (Er - Cd)*dt; % - dt/tau_v*qv_n(iz,1); % + b_v*dW(it,ins,iz);

        % Moistening
        if zi < 2/Ls
            %qv_np1(iz,1) = qv_np1(iz,1) + 2*((20/qs)/(60/Ts))*sin(pi*zi/(2/Ls))*dt;
            qv_np1(iz,1) = qv_np1(iz,1) + 2*((20/qs)/(60/Ts))*cos((pi/2)*zi/(2/Ls))*dt;
        end    
        %This is because we are updating the fluctuation theta_prime
        theta_prime_np1(iz,1) = theta_prime_np1(iz,1) - B*w_n(iz,1)*dt;
        
        %Viscosity:
        theta_prime_np1(iz,1) = theta_prime_np1(iz,1) + (nu*dt/dz^2)*(theta_prime_n(iz-1,1)-2*theta_prime_n(iz,1)+theta_prime_n(iz+1,1));
        qv_np1(iz,1) = qv_np1(iz,1) + (nu*dt/dz^2)*(qv_n(iz-1,1)-2*qv_n(iz,1)+qv_n(iz+1,1));

        %%%%%

        if wr_n(iz-1,1) < 0 && 0 <= wr_n(iz,1) %Entropy fix
            wr_imhalf_right = wr_n(iz,1)*((wr_imhalf-wr_n(iz-1,1))/(wr_n(iz,1)-wr_n(iz-1,1)));
            
            qr_imhalf = (qr_n(iz,1)+qr_n(iz-1,1))/2;
            qr_np1(iz,1) = qr_np1(iz,1) - dt/dz*wr_imhalf_right*(qr_n(iz,1)-qr_n(iz-1,1))-dt/dz*qr_imhalf*(wr_n(iz,1)-wr_n(iz-1,1));
        else
            if wr_imhalf > 0 
                qr_np1(iz,1) = qr_np1(iz,1) - dt/dz*(wr_n(iz,1)*qr_n(iz,1)-wr_n(iz-1,1)*qr_n(iz-1,1));
            end
        end
        if wr_n(iz,1) < 0 && 0 <= wr_n(iz+1,1)
            wr_iphalf_left = wr_n(iz,1)*((wr_n(iz+1,1)-wr_iphalf)/(wr_n(iz+1,1)-wr_n(iz,1)));

            qr_iphalf = (qr_n(iz+1,1)+qr_n(iz,1))/2;
            qr_np1(iz,1) = qr_np1(iz,1) - dt/dz*wr_iphalf_left*(qr_n(iz+1,1)-qr_n(iz,1))-dt/dz*qr_iphalf*(wr_n(iz+1,1)-wr_n(iz,1));
        else       
            if wr_iphalf < 0 
                qr_np1(iz,1) = qr_np1(iz,1) - dt/dz*(wr_n(iz+1,1)*qr_n(iz+1,1)-wr_n(iz,1)*qr_n(iz,1));
            end
        end
        %Condensation and evaporation parametrizations:
        qr_np1(iz,1) = qr_np1(iz,1) + (Cd-Er)*dt; % - dt/tau_r*qr_n(iz,1); % + b_r*dW(it,ins,iz);

        %Viscosity:
        qr_np1(iz,1) = qr_np1(iz,1) + (nu*dt/dz^2)*(qr_n(iz-1,1)-2*qr_n(iz,1)+qr_n(iz+1,1));
        
        %%%%%

        if wN_n(iz-1,1) < 0 && 0 <= wN_n(iz,1) %Entropy fix
            wN_imhalf_right = wN_n(iz,1)*((wN_imhalf-wN_n(iz-1,1))/(wN_n(iz,1)-wN_n(iz-1,1)));
            
            qN_imhalf = (qN_n(iz,1)+qN_n(iz-1,1))/2;
            qN_np1(iz,1) = qN_np1(iz,1) - dt/dz*wN_imhalf_right*(qN_n(iz,1)-qN_n(iz-1,1))-dt/dz*qN_imhalf*(wN_n(iz,1)-wN_n(iz-1,1));
        else
            if wN_imhalf > 0 
                qN_np1(iz,1) = qN_np1(iz,1) - dt/dz*(wN_n(iz,1)*qN_n(iz,1)-wN_n(iz-1,1)*qN_n(iz-1,1));
            end
        end
        if wN_n(iz,1) < 0 && 0 <= wN_n(iz+1,1)
            wN_iphalf_left = wN_n(iz,1)*((wN_n(iz+1,1)-wN_iphalf)/(wN_n(iz+1,1)-wN_n(iz,1)));

            qN_iphalf = (qN_n(iz+1,1)+qN_n(iz,1))/2;
            qN_np1(iz,1) = qN_np1(iz,1) - dt/dz*wN_iphalf_left*(qN_n(iz+1,1)-qN_n(iz,1))-dt/dz*qN_iphalf*(wN_n(iz+1,1)-wN_n(iz,1));
        else       
            if wN_iphalf < 0 
                qN_np1(iz,1) = qN_np1(iz,1) - dt/dz*(wN_n(iz+1,1)*qN_n(iz+1,1)-wN_n(iz,1)*qN_n(iz,1));
            end
        end

        %Viscosity:
        qN_np1(iz,1) = qN_np1(iz,1) + (nu*dt/dz^2)*(qN_n(iz-1,1)-2*qN_n(iz,1)+qN_n(iz+1,1));

    end
    
    
    %Boundary conditions:
    w_np1(1,1) = 0; 
    theta_prime_np1(1,1) = theta_prime_np1(2,1)-dz*(theta_prime_np1(3,1)-theta_prime_np1(2,1))/dz;
    qv_np1(1,1) = 20/qs; %qv_np1(2,1)-dz*(qv_np1(3,1)-qv_np1(2,1))/dz; %
    qr_np1(1,1) = qr_np1(2,1); %qr_np1(2,1)-dz*(qr_np1(3,1)-qr_np1(2,1))/dz;
    qN_np1(1,1) = 1000/CCNs*CCN_factor; %qN_np1(2,1)-dz*(qN_np1(3,1)-qN_np1(2,1))/dz; %
    
    w_np1(Nz+1,1) = 0; 
    theta_prime_np1(Nz+1,1) = 0; %theta_prime_np1(Nz,1)+dz*(theta_prime_np1(Nz,1)-theta_prime_np1(Nz-1,1))/dz;
    qv_np1(Nz+1,1) = 0; %qv_np1(Nz,1)+dz*(qv_np1(Nz,1)-qv_np1(Nz-1,1))/dz;
    qr_np1(Nz+1,1) = 0; %qr_np1(Nz,1)+dz*(qr_np1(Nz,1)-qr_np1(Nz-1,1))/dz;
    qN_np1(Nz+1,1) = 0; %qN_np1(Nz,1)+dz*(qN_np1(Nz,1)-qN_np1(Nz-1,1))/dz;
    qv_np1(Nz+1,1) = 0; %qv_np1(Nz,1);
    
    t = t+dt;

    dt
    time = t*Ts
    
    w_n = w_np1;
    theta_prime_n = theta_prime_np1;
    qv_n = qv_np1;
    qr_n = qr_np1;
    qN_n = qN_np1;
    
    if t > frame*T/NoFrames
        frame = frame+1;
        
        clf
        figure(1)
        subplot(3,3,1)
        plot(w_np1*Us,z_axis*Ls)
        axis([-10 10 0 15])
        title('w')
        subplot(3,3,2)
        plot(theta_prime_np1*Ths,z_axis*Ls)
        title('\theta pert')
        subplot(3,3,3)
        plot(Cd,z_axis*Ls)
        title('Condensation')
     
        subplot(3,3,4)
        plot(qN_np1*qs,z_axis*Ls)
        axis([0 1000 0 15])
        title('q_N')
        subplot(3,3,5)
        hold on
        plot(qv_np1*qs,z_axis*Ls)
        plot(qvs*qs,z_axis*Ls,'r -')
        title('q_v')
        subplot(3,3,6)
        plot(qr_np1*qs,z_axis*Ls)
        axis([0 5 0 15])
        title('q_r')
        print('test','-depsc',figure(1))
        hold off
    end
    
    if mod(step, 10) == 0
        data = zeros(length(z_axis), 5);
        data(:, 1) = w_np1*Us;
        data(:, 2) = theta_prime_np1*Ths;
        data(:, 3) = qv_np1*qs;
        data(:, 4) = qr_np1*qs;
        data(:, 5) = qN_np1*CCNs;
        data(:, 6) = t;
        data(:, 7) = step / 10;
        if u == 1
            writematrix(data, "data_" + string(step / 10) + "_sto.csv");
        else
            writematrix(data, "data_" + string(step / 10) + "_det.csv");
        end
    end
    step = step + 1;
    
end


%save('Resultados.mat','bWAvgArray','bWminArray','bWnArray','Phi_nArray','Phi_minArray')


